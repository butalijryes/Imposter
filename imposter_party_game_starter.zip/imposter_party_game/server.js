const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));

const WORDS = [
  "Pizza", "Basketball", "Airport", "Pancakes", "Volcano", "Concert",
  "Sunglasses", "Snowman", "Roller coaster", "Library", "Popcorn",
  "Elephant", "Beach", "Laptop", "Birthday", "Tornado", "Chocolate",
  "Football", "Camping", "Museum", "Dentist", "Waterfall", "Airplane",
  "Guitar", "Supermarket", "Halloween", "Swimming pool", "Robot",
  "Fireworks", "Sandwich", "School bus", "Dinosaur", "Wedding",
  "Coffee", "Soccer", "Movie theater", "Castle", "Umbrella", "Subway",
  "Ice cream", "Zoo", "Tennis", "Backpack", "Coconut", "Train"
];

const rooms = new Map();
const makeCode = () => {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
};
const cleanName = (s) => String(s || "").trim().replace(/[<>]/g, "").slice(0, 18);
const publicRoom = (room) => ({
  code: room.code,
  hostId: room.hostId,
  phase: room.phase,
  round: room.round,
  maxRounds: 3,
  players: [...room.players.values()].map(p => ({
    id: p.id, name: p.name, isHost: p.id === room.hostId,
    connected: p.connected, voted: room.votes.has(p.id),
    eliminated: p.eliminated
  })),
  impostersCount: room.impostersCount,
  votesSubmitted: room.votes.size,
  totalVoters: [...room.players.values()].filter(p => p.connected && !p.eliminated).length,
  message: room.message || ""
});
function emitRoom(room) {
  io.to(room.code).emit("room:update", publicRoom(room));
}
function sendPrivateRoles(room) {
  for (const p of room.players.values()) {
    io.to(p.id).emit("game:role", {
      role: p.isImposter ? "imposter" : "player",
      word: p.isImposter ? null : room.word,
      impostersCount: room.impostersCount
    });
  }
}
function finish(room, winner, message) {
  room.phase = "ended";
  room.winner = winner;
  room.message = message;
  io.to(room.code).emit("game:ended", {
    winner,
    message,
    word: room.word,
    imposters: [...room.players.values()].filter(p => p.isImposter).map(p => p.name)
  });
  emitRoom(room);
}
function startGame(room) {
  const active = [...room.players.values()].filter(p => p.connected);
  if (active.length < 4) return false;
  const count = Math.min(room.impostersCount, active.length - 2);
  const shuffled = [...active].sort(() => Math.random() - 0.5);
  const chosen = new Set(shuffled.slice(0, count).map(p => p.id));
  room.word = WORDS[Math.floor(Math.random() * WORDS.length)];
  room.round = 1;
  room.phase = "clues";
  room.votes = new Map();
  room.message = "Round 1: Take turns giving one-word clues.";
  for (const p of room.players.values()) {
    p.isImposter = chosen.has(p.id);
    p.eliminated = false;
  }
  sendPrivateRoles(room);
  emitRoom(room);
  return true;
}
function beginVote(room) {
  room.phase = "voting";
  room.votes = new Map();
  room.message = `Round ${room.round}: Vote for the player you think is an Imposter.`;
  emitRoom(room);
}
function tallyVotes(room) {
  const counts = {};
  for (const target of room.votes.values()) counts[target] = (counts[target] || 0) + 1;
  const max = Math.max(...Object.values(counts));
  const leaders = Object.keys(counts).filter(id => counts[id] === max);
  if (leaders.length !== 1) {
    room.message = "It's a tie! No one was eliminated.";
    room.phase = "round-result";
    emitRoom(room);
    return;
  }
  const target = room.players.get(leaders[0]);
  if (!target) return;
  target.eliminated = true;
  if (target.isImposter) {
    room.phase = "guess";
    room.caughtImposters = (room.caughtImposters || new Set());
    room.caughtImposters.add(target.id);
    room.message = `${target.name} was an Imposter! The Imposter team gets one guess at the secret word.`;
    io.to(room.code).emit("game:guess-turn", { playerId: target.id, playerName: target.name });
  } else {
    room.phase = "round-result";
    room.message = `${target.name} was not an Imposter.`;
  }
  emitRoom(room);
}
io.on("connection", socket => {
  socket.on("room:create", ({ name, impostersCount }, cb) => {
    const playerName = cleanName(name);
    if (!playerName) return cb?.({ error: "Enter your name first." });
    let code;
    do { code = makeCode(); } while (rooms.has(code));
    const room = {
      code, hostId: socket.id, players: new Map(),
      phase: "lobby", round: 0, votes: new Map(),
      impostersCount: Math.max(1, Math.min(3, Number(impostersCount) || 1)),
      word: null, message: "Waiting for players to join."
    };
    room.players.set(socket.id, {
      id: socket.id, name: playerName, connected: true,
      isImposter: false, eliminated: false
    });
    rooms.set(code, room);
    socket.join(code);
    cb?.({ ok: true, code, room: publicRoom(room) });
    emitRoom(room);
  });

  socket.on("room:join", ({ code, name }, cb) => {
    const room = rooms.get(String(code || "").toUpperCase().trim());
    const playerName = cleanName(name);
    if (!room) return cb?.({ error: "Room not found. Check the code and try again." });
    if (!playerName) return cb?.({ error: "Enter your name first." });
    if (room.phase !== "lobby") return cb?.({ error: "This game has already started." });
    if (room.players.size >= 30) return cb?.({ error: "This room is full." });
    if ([...room.players.values()].some(p => p.name.toLowerCase() === playerName.toLowerCase()))
      return cb?.({ error: "That name is already taken in this room." });
    room.players.set(socket.id, {
      id: socket.id, name: playerName, connected: true,
      isImposter: false, eliminated: false
    });
    socket.join(room.code);
    cb?.({ ok: true, code: room.code, room: publicRoom(room) });
    emitRoom(room);
  });

  socket.on("host:start", ({ code }, cb) => {
    const room = rooms.get(code);
    if (!room || room.hostId !== socket.id) return cb?.({ error: "Only the host can start the game." });
    if (room.players.size < 4) return cb?.({ error: "You need at least 4 players to start." });
    startGame(room);
    cb?.({ ok: true });
  });

  socket.on("host:start-vote", ({ code }, cb) => {
    const room = rooms.get(code);
    if (!room || room.hostId !== socket.id) return cb?.({ error: "Only the host can start voting." });
    if (room.phase !== "clues") return cb?.({ error: "Voting is not available right now." });
    beginVote(room);
    cb?.({ ok: true });
  });

  socket.on("player:vote", ({ code, targetId }, cb) => {
    const room = rooms.get(code);
    const voter = room?.players.get(socket.id);
    const target = room?.players.get(targetId);
    if (!room || room.phase !== "voting") return cb?.({ error: "Voting is not open." });
    if (!voter || voter.eliminated || !voter.connected) return cb?.({ error: "You cannot vote right now." });
    if (!target || target.eliminated || target.id === voter.id) return cb?.({ error: "Choose another active player." });
    if (room.votes.has(socket.id)) return cb?.({ error: "You already voted." });
    room.votes.set(socket.id, targetId);
    cb?.({ ok: true });
    const eligible = [...room.players.values()].filter(p => p.connected && !p.eliminated);
    if (eligible.every(p => room.votes.has(p.id))) tallyVotes(room);
    else emitRoom(room);
  });

  socket.on("imposter:guess", ({ code, guess }, cb) => {
    const room = rooms.get(code);
    const player = room?.players.get(socket.id);
    if (!room || room.phase !== "guess" || !player?.isImposter || !room.caughtImposters?.has(socket.id))
      return cb?.({ error: "You don't have the guess right now." });
    const correct = String(guess || "").trim().toLowerCase() === room.word.toLowerCase();
    if (correct) {
      finish(room, "imposters", `The Imposter team guessed the word correctly: ${room.word}.`);
    } else {
      room.message = "Wrong guess!";
      const allCaught = [...room.players.values()].filter(p => p.isImposter).every(p => room.caughtImposters.has(p.id));
      if (allCaught) finish(room, "players", "All Imposters were identified!");
      else {
        room.phase = "round-result";
        emitRoom(room);
      }
    }
    cb?.({ ok: true, correct });
  });

  socket.on("host:next-round", ({ code }, cb) => {
    const room = rooms.get(code);
    if (!room || room.hostId !== socket.id) return cb?.({ error: "Only the host can continue." });
    if (!["round-result", "guess"].includes(room.phase)) return cb?.({ error: "The round cannot advance yet." });
    if (room.phase === "guess") return cb?.({ error: "Wait for the Imposter's guess." });
    if (room.round >= 3) {
      finish(room, "imposters", "Three rounds are over. The Imposter team wins!");
    } else {
      room.round += 1;
      room.phase = "clues";
      room.votes = new Map();
      room.message = `Round ${room.round}: Take turns giving one-word clues.`;
      emitRoom(room);
    }
    cb?.({ ok: true });
  });

  socket.on("disconnect", () => {
    for (const room of rooms.values()) {
      const p = room.players.get(socket.id);
      if (p) {
        p.connected = false;
        if (room.hostId === socket.id && room.phase === "lobby") {
          const next = [...room.players.values()].find(x => x.connected);
          if (next) room.hostId = next.id;
        }
        emitRoom(room);
        if ([...room.players.values()].every(x => !x.connected)) rooms.delete(room.code);
      }
    }
  });
});

server.listen(PORT, () => console.log(`Imposter game running on port ${PORT}`));
