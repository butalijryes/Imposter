# Imposter Party Game

A real-time, phone-friendly multiplayer Imposter game built with Express and Socket.IO.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` in a browser.

For testing on the same Wi-Fi, other phones can open `http://YOUR-COMPUTER-LAN-IP:3000`.

## Publish it online for QR-code joining
Deploy this folder to a Node.js host that supports persistent WebSocket connections (for example Render or Railway):
- Build command: `npm install`
- Start command: `npm start`
- The app serves the website and Socket.IO from the same origin.
- Once deployed, the host's public URL becomes the join URL and the in-room QR code points to it.

## Game flow
- Host creates a room and chooses 1–3 imposters.
- Players join by room code or QR code.
- At least 4 players are required.
- Host starts the game; each player privately reveals their role on their own device.
- Players discuss and give one-word clues.
- Host opens voting; everyone votes once.
- If an Imposter is voted out, the Imposter team gets one guess at the secret word.
- If an innocent player is voted out, the host can continue to the next clue round.
- The group has up to 3 clue rounds. If the Imposters have not all been identified by the end of round 3, the Imposters win.

## Notes
- This starter version keeps active rooms in server memory. Restarting/redeploying the server clears current games.
- It is designed for casual party play, not high-stakes security. Players should avoid reloading during a live game.
- The QR code is generated automatically after the host creates a room and works once the app is deployed to a public URL.
